let request = require('request');

let url = `http://api.openweathermap.org/data/2.5/weather?lat=53.1982&lon=-8.5691&appid=3dc14e5a852359d8ae6d0097025ce62e`


request(url, function (err, response, body) {   
  if(err){
    console.log('error:', error);
  } else {
    let weather = JSON.parse(body)

       var Celcius_Temp = weather.main.temp - 273.15
       var Preasure = weather.main.pressure
       var Humidity = weather.main.humidity
       var WindSpeed = weather.wind.speed
       var Description = weather.weather[0].description
       var CloudCover = weather.clouds.all
       var Area = weather.name
      
    console.log(Area);
    console.log(Celcius_Temp);
    console.log(Preasure);
    console.log(Humidity);
    console.log(WindSpeed);
    console.log(Description);
    console.log(CloudCover);
    console.log('body:', body);
  }
});
